﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace quanlikhachsan
{
    public partial class trangchu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void btnxemthemhnghi_Click(object sender, EventArgs e)
        {
            Response.Redirect("phongstd.aspx");
        }
        public void btnxemthemnhahang_Click(object sender, EventArgs e)
        {
            Response.Redirect("phongsup.aspx");
        }
        public void btnxemthembeboi_Click(object sender, EventArgs e)
        {
            Response.Redirect("phongdlx.aspx");
        }
        public void btnxemthemgym_Click(object sender, EventArgs e)
        {
            Response.Redirect("phongsut.aspx");
        }
        public void btnxemthemspa_Click(object sender, EventArgs e)
        {
            Response.Redirect("phongconn.aspx");
        }
        public void btnxemthemkhuvuichoi_Click(object sender, EventArgs e)
        {

        }

    }
}