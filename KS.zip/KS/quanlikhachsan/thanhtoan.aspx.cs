﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace quanlikhachsan
{
    public partial class thanhtoan : System.Web.UI.Page
    {
        access ac = new access();
        protected void Page_Load(object sender, EventArgs e)
        {
            txtcmnd.Text = datphong.Truyendulieu.cmnd;
            txthoten.Text = datphong.Truyendulieu.hoten;
            txtsotien.Text = datphong.Truyendulieu.loaiphong;
            if (txtsotien.Text == "STD")
            {
                txtsotien.Text = "800000";
            }
            if (txtsotien.Text == "SUP")
            {
                txtsotien.Text = "1100000";
            }
            if (txtsotien.Text == "DLX")
            {
                txtsotien.Text = "1000000";
            }
            if (txtsotien.Text == "SUT")
            {
                txtsotien.Text = "2500000";
            }
            if (txtsotien.Text == "CR")
            {
                txtsotien.Text = "2500000";
            }
        }
        #region Thanh toan
        protected void btnthanhtoan_Click(object sender, EventArgs e)
        {
            string hoten = txthoten.Text;
            string tentaikhoan = txttentaikhoan.Text;
            string sotien = txtsotien.Text;
            string masothe = txtmasothe.Text;
            string httt = ddlloaiphong.Text;
            string cmnd = txtcmnd.Text;
            int n = 0;
            if (int.TryParse(this.txtmasothe.Text, out n) && Int32.Parse(txtmasothe.Text) > 15)
            {

            }
            else
            {
                txtmasothe.Text = "";
                Response.Write("<script>alert('Thông tin không hợp lệ. Ma so the 16 so');</script>");
                return;
            }
            if (hoten == ""||sotien==""||masothe==""||httt==""||cmnd==""||tentaikhoan=="")
            {
                Response.Write("<script>alert('Bạn chưa nhập đầy đủ thông tin!');</script>");
            }
            else
            {
                System.Text.RegularExpressions.Regex.IsMatch(txtmasothe.Text, "[ ^ 0-9]");
                ac.query("Insert into thanhtoan values('" + hoten + "','" + cmnd + "','" +tentaikhoan + "','" + sotien + "','" + masothe+ "','" + httt +"')");
                hoten = "";
                tentaikhoan = "";
                sotien = "";
                masothe = "";
                httt = "";
                cmnd = "";
                Response.Write("<script>alert('Thanh toán thành công');</script>");
            }
        }
        #endregion

    }

}