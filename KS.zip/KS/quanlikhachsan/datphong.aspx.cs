﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace quanlikhachsan
{
    public partial class datphong : System.Web.UI.Page
    {
        access ac = new access();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lichden.Visible = false;
                lichdi.Visible = false;
            }
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (lichden.Visible == false)
            {
                lichden.Visible = true;
            }
            else
                lichden.Visible = false;
        }
        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (lichdi.Visible == false)
            {
                lichdi.Visible = true;
            }
            else
                lichdi.Visible = false;
        }
        protected void btndatphong_Click(object sender, EventArgs e)
        {
            #region kiểm tra
            String loaiphong = ddlloaiphong.Text;
            String ngayden =txtngayden.Text;
            String ngaydi =txtngaydi.Text;
            String nguoilon =txtnglon.Text;
            String treem =txttreem.Text;
            String giuongphu =txtgiuongphu.Text;
            string maphong = txtMaPhong.Text;
            String hoten =txthoten.Text;
            String diachi =txtdiachi.Text;
            String cmnd = txtcmnd.Text;
            String sdt =txtsdt.Text;
            String email = txtemail.Text;
            int n = 0;

            if (int.TryParse(this.txtnglon.Text, out n) && Int32.Parse(txtnglon.Text) > 0)
            {

            }
            else
            {
                nguoilon = "";

                Response.Write("<script>alert('Thông tin không hợp lệ.');</script>");
                return;
            }

           
            if (int.TryParse(this.txttreem.Text, out n))
            {

            }
            else
            {
                treem = "";
                Response.Write("<script>alert('Thông tin không hợp lệ.');</script>");
                return;
            }
         
            if (int.TryParse(this.txtgiuongphu.Text, out n))
            {

            }
            else
            { txtgiuongphu.Text = ""; Response.Write("<script>alert('Thông tin không hợp lệ.');</script>"); return; }

            
            if (int.TryParse(this.txtcmnd.Text, out n) && txtcmnd.Text.Length == 9)
            {

            }
            else { cmnd = ""; Response.Write("<script>alert('Thông tin không hợp lệ. CMNN gồm 9 số!');</script>"); return;
            }
            if (int.TryParse(this.txtsdt.Text, out n) && txtsdt.Text.Length == 10)
            {

            }
            else
            {
                sdt = "";
                Response.Write("<script>alert('Thông tin không hợp lệ. SDT gồm 10 số!');</script>");
                return;
            }

            if (maphong==""||loaiphong=="" ||ngayden==""||ngaydi==""||nguoilon == "" ||treem == "" ||giuongphu == "" || hoten == "" ||diachi == "" ||cmnd == "" ||sdt == "" ||email == "" )
            {
                Response.Write("<script>alert('Chưa nhập đầy đủ thông tin!');</script>");return;
            }
            else
            {
                string lp = Convert.ToString(ac.query("select maloaiphong from datphong where maloaiphong like'" + ddlloaiphong.SelectedValue.ToString() + "'"));
                if (loaiphong == lp)
                {
                    Response.Write("<script>alert('Loại phòng bạn muốn đặt đã hết! Vui lòng chọn loại phòng khác phù hợp!');</script>");
                }
                else
                {

                    ac.query("Insert into datphong values(N'" + txtMaPhong.Text + "','" + txtngayden.Text + "','" + txtngaydi.Text + "','" + txtsodem.Text + "','" + ddlloaiphong.Text + "','" + txtnglon.Text + "','" + txttreem.Text + "','" + txtgiuongphu.Text + "','" + txtcmnd.Text + "')");
                    ac.query("Insert into khachhang values(N'" + txthoten.Text + "','" + txtdiachi.Text + "','" + txtcmnd.Text + "','" + txtsdt.Text + "','" + txtemail.Text + "')");
                    Response.Write("<script>alert('Đặt phòng thành công!');</script>");

                    Truyendulieu.hoten = txthoten.Text;
                    Truyendulieu.cmnd = txtcmnd.Text;
                    Truyendulieu.loaiphong = ddlloaiphong.Text;                  
                    Response.Redirect("thanhtoan.aspx");
                }
            }
            #endregion
           // String mlp = Convert.ToString("Select MaLoaiPhong from loaiphong where MaLoaiPhong ='" + ddlloaiphong.SelectedValue + "'");

            //String mp = Convert.ToString(ac.query("select MaPhong from Phong where TinhTrang like N'%Trống%' and MaLoaiPhong like'" + ddlloaiphong.SelectedValue.ToString() + "'"));
            //String maphong = Convert.ToString(ac.query("select TOP(1) MaPhong from Phong where TinhTrang like N'%Trống%' and MaLoaiPhong like'" + ddlloaiphong.SelectedValue.ToString()+ "'"));


        }
        public class Truyendulieu
        {
            static public string hoten;
            static public string cmnd;
            static public string loaiphong;
        }

        protected void lichden_SelectionChanged(object sender, EventArgs e)
        {
            txtngayden.Text = lichden.SelectedDate.ToShortDateString();
            DateTime ngayden = Convert.ToDateTime(txtngayden.Text);
            var today = DateTime.Now;
            var duration = new TimeSpan(0, 0, 0, 0);
            DateTime newday = today.Add(duration);

            if (newday > ngayden)
            {
                txtngayden.Text = "";
                Response.Write("<script>alert('Thông tin không hợp lệ. Ngày đến lớn hơn ngày hiện tại!');</script>");
                lichden.Visible = false;
            }
        }

        protected void lichdi_SelectionChanged(object sender, EventArgs e)
        {
            txtngaydi.Text = lichdi.SelectedDate.ToShortDateString();
            lichdi.Visible = false;
            txtsodem_TextChanged();
        }
        protected void txtcmnd_TextChanged(object sender, EventArgs e)
        {
            int n = 0;
            if (int.TryParse(this.txtcmnd.Text, out n) && txtcmnd.Text.Length == 9)
            {
                
            }
            else
                Response.Write("<script>alert('Thông tin không hợp lệ. CMNN gồm 9 số!');</script>");

        }

        protected void txtsodem_TextChanged()
        {
                DateTime ngayden = Convert.ToDateTime(txtngayden.Text);
                DateTime ngaydi = Convert.ToDateTime(txtngaydi.Text);
                TimeSpan Time = ngaydi - ngayden;
            
            if(txtngayden.Text != null && txtngaydi.Text!= null && ngaydi>ngayden )
            {                
                txtsodem.Text = Convert.ToString(Time.Days);
            }
            else
            {
                txtngaydi.Text = "";
                Response.Write("<script>alert('Thông tin không hợp lệ. Ngày đi lớn hơn ngày đến!');</script>");
            }
        }

        protected void txtnglon_TextChanged(object sender, EventArgs e)
        {
            int n = 0;
            if (int.TryParse(this.txtnglon.Text, out n) && Int32.Parse(txtnglon.Text) >0)
            {

            }
            else
                Response.Write("<script>alert('Thông tin không hợp lệ. Người lớn lớn hơn 0!');</script>");

        }

        protected void txttreem_TextChanged(object sender, EventArgs e)
        {

            int n = 0;
            if (int.TryParse(this.txttreem.Text, out n))
            {

            }
            else
                Response.Write("<script>alert('Thông tin không hợp lệ. ');</script>");
        }

        protected void txtgiuongphu_TextChanged(object sender, EventArgs e)
        {

            int n = 0;
            if (int.TryParse(this.txttreem.Text, out n))
            {

            }
            else
                Response.Write("<script>alert('Thông tin không hợp lệ. Ghi số!');</script>");

        }

        protected void txtsdt_TextChanged(object sender, EventArgs e)
        {
            int n = 0;
            if (int.TryParse(this.txtsdt.Text, out n) && txtsdt.Text.Length == 10)
            {

            }
            else
                Response.Write("<script>alert('Thông tin không hợp lệ. SDT gồm 10 số!');</script>");

        }
    }
}